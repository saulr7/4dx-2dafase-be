package models

type Email struct {
	ProfileName   string
	Recipients    string
	Subject       string
	Body          string
	ColaboradorId string
}
